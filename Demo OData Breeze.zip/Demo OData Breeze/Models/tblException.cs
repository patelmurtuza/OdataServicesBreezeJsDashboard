﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DemoBreeze.Models
{


    public class tblException
    {
        public int Id { get; set; }
        public Nullable<System.DateTime> ErrorDate { get; set; }
        public string UserName { get; set; }
        public string ErrorMsg { get; set; }
        public string Stack { get; set; }
        public string Method { get; set; }

    }


}