﻿var TableObject;
function DestroyTable(TableObject) {
    TableObject.fnDestroy();
}

function formatSearchResults(TableName, aryJSONTable, highlightrows) {
    DestroyTable($(TableName).dataTable());
    TableObject = jQuery(TableName).dataTable({
        "dom": 'CT<"clear">zRlfrtip',
        "oTableTools": {
            "sSwfPath": "../Scripts/datatable/extensions/TableTools/swf/copy_csv_xls.swf",
            "aButtons": [
            {
                "sExtends": "collection",
                "sPdfOrientation": "landscape",
                "sButtonText": "<span>Export Data</span>",
                "aButtons": ["csv", "xls", "pdf"]
            }
            ]
        },
        "bPaginate": true,
        "sPaginationType": "input",
        "aoColumnDefs": aryJSONTable,
        "bAutoWidth": false
    });

    if (highlightrows != undefined) {
        var rows = $(TableName).dataTable().fnGetNodes();
        for (i = 0; i < rows.length; i++)
            fnclearHighlightrows(TableName, highlightrows[i], 5)

        for (i = 0; i < highlightrows.length; i++)
            fnHilightRows(TableName, highlightrows[i], 5)
    }


}