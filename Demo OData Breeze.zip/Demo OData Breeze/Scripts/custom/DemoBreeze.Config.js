﻿document.DemoBreeze = {
    topServiceRecord: 100,
    RESTApiUrl: '/oData/',
    authKey: 'Basic dmlhY29tX2NvcnBcZGhpbGxvbnY6VmlhY29tMTEx',
    apiKey: 'D8CA3617-1C7A-467E-B7AE-E1FD5141580B',
    acceptHeaderBreeze: 'application/json;odata=verbose',
    acceptHeaderAjax: 'application/json',
    ContentType: 'application/json',
    MaxDataVersion: '3.0',
    initializeStatusCustomers: true,
    initializeStatusexception: true,
    selectedTab: "Customer",
    defaultDateDuration:3
}
