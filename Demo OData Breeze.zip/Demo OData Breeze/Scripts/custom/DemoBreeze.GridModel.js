﻿function fnAliasCustomersGridModel() {

    var viscols = [];
    var rawviscols = localStorage["lstUnwantedCustomersCols"];
    if (rawviscols != undefined)
        viscols = JSON.parse(localStorage["lstUnwantedCustomersCols"]);

    var aryJSONTable = [
         {
             "sTitle": "Customer ID",
             "aTargets": 0,
             "visible": getval(viscols, 0),
             "sWidth": "6%"
         },
          {
              "sTitle": "First Name",
              "aTargets": 1,
              "visible": getval(viscols, 1),
              "sWidth": "10%"

          },
         {
             "sTitle": "Last Name",
             "aTargets": 2,
             "visible": getval(viscols, 2),
             "sWidth": "10%"

         },
         {
             "sTitle": "City",
             "aTargets": 3,
             "visible": getval(viscols, 3),
             "sWidth": "10%"

         },
          {
              "sTitle": "State",
              "aTargets": 4,
              "visible": getval(viscols, 4),
              "sWidth": "13%"

          },
          {
              "sTitle": "Zip",
              "aTargets": 5,
              "visible": getval(viscols, 5),
              "sWidth": "8%"

          },
          {
              "sTitle": "Time Stamp",
              "aTargets": 6,
              "mRender": function (data, type, full) {
                  if (data) {
                      mDate = moment(data);
                      return (mDate && mDate.isValid()) ? mDate.format("MM-DD-YYYY hh:mm:ss a") : "";
                  }

              },
              "visible": getval(viscols, 6),
              "sWidth": "13%"

          }

    ];

    return aryJSONTable
}

function fnAliasErrorLogGridModel() {
    var viscols = [];
    var rawviscols = localStorage["lstUnwantedExceptionCols"];
    if (rawviscols != undefined)
        viscols = JSON.parse(localStorage["lstUnwantedExceptionCols"]);

    var aryJSONTable = [

        {
            "sTitle": "Id",
            "aTargets": 0,
            "sWidth": "3%",
            "visible": getval(viscols, 0)
        },
        {
            "sTitle": "Error Date",
            "aTargets": 1,
            "mRender": function (data, type, full) {
                if (data) {
                    mDate = moment(data);
                    return (mDate && mDate.isValid()) ? mDate.format("MM-DD-YYYY hh:mm:ss a") : "";
                }

            },
            "visible": getval(viscols, 1),
            "sWidth": "13%"
        },
         {
             "sTitle": "Username",
             "aTargets": 2,
             "visible": getval(viscols, 2),
             "sWidth": "10%"
         },
        {
            "sTitle": "Error Message",
            "aTargets": 3,
            "visible": getval(viscols, 3),
            "sWidth": "15%"
        },
        {
            "sTitle": "Stack",
            "aTargets": 4,
            "visible": getval(viscols, 4),
            "sWidth": "15%"
        },
    {
        "sTitle": "Method",
        "aTargets": 5,
        "visible": getval(viscols, 5),
        "sWidth": "15%"
    }
    ];

    return aryJSONTable;
}

function getval(viscols, idx) {
    for (var i = 0; i < viscols.length; i++) {
        if (viscols[i] == idx)
            return false;
    }
    return true;
}


