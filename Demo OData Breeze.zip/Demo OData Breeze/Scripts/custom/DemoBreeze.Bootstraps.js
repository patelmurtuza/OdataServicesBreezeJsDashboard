﻿$(function () {
	$('.datepicker').datepicker({
		autoclose: true

	})

	$('#date').datepicker()
   .on("changeDate", function (e) {

   });
});

$(document).ready(function () {
	function toggleChevron(e) {
		$(e.target)
			.prev('.panel-heading')
			.find("i.indicator")
			.toggleClass('glyphicon-chevron-down glyphicon-chevron-up');
	}
	$('#accordion').on('hidden.bs.collapse', toggleChevron);
	$('#accordion').on('shown.bs.collapse', toggleChevron);
	$('#accordion1').on('hidden.bs.collapse', toggleChevron);
	$('#accordion1').on('shown.bs.collapse', toggleChevron);
	$('#accordion2').on('hidden.bs.collapse', toggleChevron);
	$('#accordion2').on('shown.bs.collapse', toggleChevron);
	$('#accordion3').on('hidden.bs.collapse', toggleChevron);
	$('#accordion3').on('shown.bs.collapse', toggleChevron);
});
