﻿var arrGridData = [];

function fnProcessBreezeData(headerflag, data, entityname) {
    var idx = 0;
    switch (entityname) {
        case "Customers":
            {
                alias.DemoBreeze.Customers([]);
                alias.DemoBreeze.columnsCustomers([]);
                if (!headerflag) {
                    arrGridData = [];
                    if (data.results.length != 0) {
                        $.each(data.results, function (i, c) {
                            arrGridData[i] = { "CustomerID": c.CustomerID, "FirstName": c.FirstName, "LastName": c.LastName, "City": c.City, "State": c.State, "Zip": c.Zip, "Timestamp": c.Timestamp };
                        });
                        alias.DemoBreeze.Customers(arrGridData);
                    }
                }
                arrGridData = [];
                arrGridData[0] = new column("Customer ID", "CustomerID", 0);
                arrGridData[1] = new column("First Name", "FirstName", 1);
                arrGridData[2] = new column("Last Name", "LastName", 2);
                arrGridData[3] = new column("City", "City", 3);
                arrGridData[4] = new column("State", "State", 4);
                arrGridData[5] = new column("Zip", "Zip", 5);
                arrGridData[6] = new column("Timestamp", "Timestamp", 6);
                alias.DemoBreeze.columnsCustomers(arrGridData);
            }

            break;

        case "Exceptions":
            {
                alias.DemoBreeze.exceptions([]);
                alias.DemoBreeze.columnsException([]);
                document.DemoBreeze.stackvalues = [];
                if (!headerflag) {
                    arrGridData = [];
                    if (data.results.length != 0) {
                        $.each(data.results, function (i, c) {

                            arrGridData[i] = { "Id": c.Id, "ErrorDate": c.ErrorDate, "UserName": c.UserName, "ErrorMsg": c.ErrorMsg, "Stack": c.Stack, "Method": c.Method };
                        });
                        alias.DemoBreeze.exceptions(arrGridData);
                    }
                }

                arrGridData = [];
                arrGridData[0] = new column("Id", "Id", 0);
                arrGridData[1] = new column("Error Date", "ErrorDate", 1);
                arrGridData[2] = new column("Username", "UserName", 2);
                arrGridData[3] = new column("Error Message", "ErrorMsg", 3);
                arrGridData[4] = new column("Stack", "Stack", 4);
                arrGridData[5] = new column("Method", "Method", 5);
                alias.DemoBreeze.columnsException(arrGridData);
            }
            break;
    }

}
