﻿var alias = {};


var column = function (hname, pname, idx) {
    this.propertyName = pname;
    this.columnHeader = hname;
    this.columnIndex = idx;
}

$(function () {
    breeze.config.initializeAdapterInstances({ dataService: "OData" });
});

alias.DemoBreeze = {
    Customers: ko.observableArray([]),
    exceptions: ko.observableArray([]),
    columnsCustomers: ko.observableArray(),
    columnsException: ko.observableArray(),
}
var viewModel = {
    vmCustomers: alias.DemoBreeze.Customers,
    vmcolumnsCustomers: alias.DemoBreeze.columnsCustomers,
    vmexceptions: alias.DemoBreeze.exceptions,
    vmcolumnsException: alias.DemoBreeze.columnsException
};

$(document).ready(function () {
    AliasShowUpdateModal("DemoBreeze Customers Startup is in progress.");
    var toLoaddt = (Date(), moment().format('DD.MM.YYYY'));
    var fromLoaddt = (moment().subtract({ 'days': document.DemoBreeze.defaultDateDuration })).format('DD.MM.YYYY');
    var toLoaddtDisplay = (Date(), moment().format('MM-DD-YYYY'));
    var fromLoaddtDisplay = (moment().subtract({ 'days': document.DemoBreeze.defaultDateDuration })).format('MM-DD-YYYY');
    $('#tblCustomersTableFromDate').val(fromLoaddtDisplay);
    $('#tblCustomersTableToDate').val(toLoaddtDisplay);
    $('#tblExceptionTableFromDate').val(fromLoaddtDisplay);
    $('#tblExceptionTableToDate').val(toLoaddtDisplay);

    fnInitializeCustomersHeader(fromLoaddt, toLoaddt);

    fnInitializeExceptionHeader(fromLoaddt, toLoaddt);

    ko.applyBindings(viewModel);

    $('.nav.nav-tabs > li.active > a').trigger('click');
    $('.nav.nav-tabs > li > a').on('click', function () {
        var DataCondition = $(this).text();
        if (DataCondition == "Customer") {
            document.DemoBreeze.selectedTab = "Customer";
        }
        else if (DataCondition == "Error Log") {
            if (document.DemoBreeze.initializeStatusexception) {
                fnSearchException("Initializing Error Log , Please wait");
                document.DemoBreeze.initializeStatusexception = false;
            }
            document.DemoBreeze.selectedTab = "Exceptions";
        }
    });

});

viewModel.Reset = function () {
    viewModel.vmCustomers([]),
    viewModel.vmcolumnsCustomers([]),
    viewModel.vmexceptions([]),
    viewModel.vmcolumnsException([])
}

function fnSearchCustomers(title) {
    var txtSearch = $('#txtCustomersSearch').val().trim();
    var fromdt = $('#tblCustomersTableFromDate').val();
    var todt = $('#tblCustomersTableToDate').val();
    var fromdtVer = fromdt.split("-")[1] + "." + fromdt.split("-")[0] + "." + fromdt.split("-")[2];
    var todtVer = todt.split("-")[1] + "." + todt.split("-")[0] + "." + todt.split("-")[2];
    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var fromdtVerDisplay = moment(fromdtVer, "DD.MM.YYYY").toDate();
        var todtVerDisplay = moment(todtVer, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
        if (fromdtVerDisplay > todtVerDisplay) {
            AliasAlert("From Date cannot be greater than To Date", "Warning");
            return false;
        }
        AliasShowUpdateModal(title);
        $("#tblCustomersTable").dataTable().fnClearTable();
        $("#tblCustomersTable").dataTable().fnDestroy();
        $("#tblCustomersTable thead tr").removeAttr('role');
        $("#tblCustomersTable").removeAttr('role');
        $("#tblCustomersTable").removeAttr('aria-describedby');
        ko.mapping.fromJS(alias.DemoBreeze.columnsCustomers, {}, viewModel.vmcolumnsCustomers);
        ko.mapping.fromJSON(alias.DemoBreeze.Customers, {}, viewModel.vmCustomers);
    }
    fnGetCustomersServiceFilterData(txtSearch, fromdtVer, todtVer);
}

function fnSearchException(title) {
    var txtSearch = $('#txtexceptionSearch').val().trim();
    var fromdt = $('#tblExceptionTableFromDate').val();
    var todt = $('#tblExceptionTableToDate').val();
    var fromdtVer = fromdt.split("-")[1] + "." + fromdt.split("-")[0] + "." + fromdt.split("-")[2];
    var todtVer = todt.split("-")[1] + "." + todt.split("-")[0] + "." + todt.split("-")[2];
    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var fromdtVerDisplay = moment(fromdtVer, "DD.MM.YYYY").toDate();
        var todtVerDisplay = moment(todtVer, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
        if (fromdtVerDisplay > todtVerDisplay) {
            AliasAlert("From Date cannot be greater than To Date", "Warning");
            return false;
        }
    }
    AliasShowUpdateModal(title);
    $("#tblExceptionTable").dataTable().fnClearTable();
    $("#tblExceptionTable").dataTable().fnDestroy();
    $("#tblExceptionTable thead tr").removeAttr('role');
    $("#tblExceptionTable").removeAttr('role');
    $("#tblExceptionTable").removeAttr('aria-describedby');
    ko.mapping.fromJS(alias.DemoBreeze.columnsException, {}, viewModel.vmcolumnsException);
    ko.mapping.fromJSON(alias.DemoBreeze.exceptions, {}, viewModel.vmexceptions);
    fnGetExceptionServiceFilterData(txtSearch, fromdtVer, todtVer);
}

function AliasShowUpdateModal(title) {
        $(".modal-text").html(title);
        $body = $("body");
        $body.addClass("loading");
}

function AliasHideUpdateModal() {
    $body = $("body");
    $body.removeClass("loading");
    $("body").css("cursor", "default");

}

function closeWindow() {
    if (confirm("Are you sure you want to log out from the application?")) {
        window.close();
    }
}


function AliasAlert(msg, dgtitle) {
    BootstrapDialog.show({
        title: dgtitle,
        message: msg,
        buttons: [{
            label: 'Close',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}
