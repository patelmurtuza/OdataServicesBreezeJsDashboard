﻿

function fnInitializeCustomersHeader(fromdt, todt) {

    var serverAddress = document.DemoBreeze.RESTApiUrl;
    var manager = new breeze.EntityManager(serverAddress);
    var predicate = new breeze.Predicate();
    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var fromdt = moment(fromdt, "DD.MM.YYYY").toDate();
        var todt = moment(todt, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
        var gtfromdt = new breeze.Predicate.create("Timestamp", ">=", fromdt);
        var lttodt = new breeze.Predicate.create("Timestamp", "<=", todt);
        predicate = breeze.Predicate.and(gtfromdt, lttodt);
    }

    var qryCustomers = breeze.EntityQuery.from("Customers").where(predicate).select('CustomerID,FirstName, LastName, City,State,Zip');
    manager.executeQuery(qryCustomers).then(function (data) {
        fnProcessBreezeData(false, data, "Customers");
        var aryJSONCustomers = fnAliasCustomersGridModel();
        formatSearchResults('#tblCustomersTable', aryJSONCustomers);
        AliasHideUpdateModal();
    }).fail(function (err) {
        AliasAlert("DemoBreeze Customers service encountered an internal error.\n Please retry the request.", "DemoBreeze Customers Error");
        AliasHideUpdateModal();
    });
}

function fnGetCustomersServiceFilterData(txtSearch, fromdt, todt, pageClick) {
    var serverAddress = document.DemoBreeze.RESTApiUrl;;
    var manager = new breeze.EntityManager(serverAddress);
    var Predicate = new breeze.Predicate;
    var baseQuery = breeze.EntityQuery.from("Customers");

    var ctFirstName = new breeze.Predicate("FirstName", "Contains", txtSearch);
    var ctLastName = new breeze.Predicate("LastName", "Contains", txtSearch);
    var ctCity = new breeze.Predicate("City", "Contains", txtSearch);
    var fromdt = moment(fromdt, "DD.MM.YYYY").toDate();
    var todt = moment(todt, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
    var gtfromdt = new breeze.Predicate.create("Timestamp", ">=", fromdt);
    var lttodt = new breeze.Predicate.create("Timestamp", "<=", todt);

    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined) && (txtSearch != "" && txtSearch != undefined)) {
        var compositePred = gtfromdt.and(lttodt).and((ctFirstName).or(ctLastName).or(ctCity));
    }
    else if (txtSearch != "" && txtSearch != undefined) {
        var compositePred = ctFirstName.or(ctLastName).or(ctCity);
    }
    else if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var compositePred = gtfromdt.and(lttodt);
    }
    var qryCustomersSearch = baseQuery.where(compositePred).select('CustomerID,FirstName, LastName, City,State,Zip');

    manager.executeQuery(qryCustomersSearch).then(function (data) {
        fnProcessBreezeData(false, data, "Customers");
        var aryJSONCustomers = fnAliasCustomersGridModel();
        formatSearchResults('#tblCustomersTable', aryJSONCustomers);
        AliasHideUpdateModal();

    }).fail(function (err) {

        AliasAlert("Customers Service is unable to fetch data due to wide date range. \n Please narrow down the date range", "DemoBreeze Error");
        AliasHideUpdateModal();

    });
}

function fnInitializeExceptionHeader(fromdt, todt) {
    var serverAddressEL = document.DemoBreeze.RESTApiUrl;
    var managerEL = new breeze.EntityManager(serverAddressEL);
    var predicate = new breeze.Predicate();
    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var fromedt = moment(fromdt, "DD.MM.YYYY").toDate();
        var toedt = moment(todt, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
        var gtfromedt = new breeze.Predicate.create("ErrorDate", ">=", fromedt);
        var lttoedt = new breeze.Predicate.create("ErrorDate", "<=", toedt);
        predicate = breeze.Predicate.and(gtfromedt, lttoedt);
    }
    var qryExceptions = breeze.EntityQuery.from("tblExceptions").orderBy('Method').where(predicate);
    managerEL.executeQuery(qryExceptions).then(function (data) {
        fnProcessBreezeData(true, data, "Exceptions");
    }).fail(function (err) {
        AliasAlert("Exception Error Log service encountered an internal error.\n Please retry the request.", "DemoBreeze Error");
        AliasHideUpdateModal();
    });

}

function fnGetExceptionServiceFilterData(txtSearch, fromdt, todt) {
    var serverAddress = document.DemoBreeze.RESTApiUrl;
    var manager = new breeze.EntityManager(serverAddress);
    var Predicate = new breeze.Predicate;
    var baseQuery = breeze.EntityQuery.from("tblExceptions");

    var ctUserName = new breeze.Predicate.create("UserName", 'Contains', txtSearch);
    var ctErrorMsg = new breeze.Predicate.create("ErrorMsg", "Contains", txtSearch);
    var ctStack = new breeze.Predicate.create("Stack", "Contains", txtSearch);
    var ctMethod = new breeze.Predicate.create("Method", "Contains", txtSearch);
    var fromdt = moment(fromdt, "DD.MM.YYYY").toDate();
    var todt = moment(todt, "DD.MM.YYYY").add(23, 'hours').add(59, 'minutes').toDate();
    var gtfromdt = new breeze.Predicate.create("ErrorDate", ">=", fromdt);
    var lttodt = new breeze.Predicate.create("ErrorDate", "<=", todt);

    if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined) && (txtSearch != "" && txtSearch != undefined)) {
        var compositePred = gtfromdt.and(lttodt).and((ctUserName).or(ctErrorMsg).or(ctStack).or(ctMethod));
    }
    else if (txtSearch != "" && txtSearch != undefined) {
        var compositePred = ctUserName.or(ctErrorMsg).or(ctStack).or(ctMethod);
    }
    else if ((fromdt != "" && fromdt != undefined) && (todt != '' && todt != undefined)) {
        var compositePred = gtfromdt.and(lttodt);
    }
    var qryExceptionSearch = baseQuery.orderBy('Method').where(compositePred);

    manager.executeQuery(qryExceptionSearch).then(function (data) {

        fnProcessBreezeData(false, data, "Exceptions");
        var aryJSONErrorLog = fnAliasErrorLogGridModel();
        formatSearchResults('#tblExceptionTable', aryJSONErrorLog);
        AliasHideUpdateModal();

    }).fail(function (err) {

        AliasAlert("Exception Error Log Service encountered an internal error. \n If problem persists, Please contact Administrator", "DemoBreeze Error");
        AliasHideUpdateModal();
    });
}

