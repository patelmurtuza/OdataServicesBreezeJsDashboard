﻿using DemoBreeze.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using System.Web.Http.OData.Query;

namespace DemoBreeze
{
    public class tblExceptionsController : EntitySetController<tblException, string>
    {
        TestDbContext _Context = new TestDbContext();
        HttpConfiguration config = new HttpConfiguration();
        [Queryable]
        public override IQueryable<tblException> Get()
        {
            try
            {
                return _Context.tblException;
            }
            catch (Exception ex)
            {
                
                throw;
            }
           
        }

        protected override void Dispose(bool disposing)
        {

            base.Dispose(disposing);

            _Context.Dispose();

        }
    }

}
